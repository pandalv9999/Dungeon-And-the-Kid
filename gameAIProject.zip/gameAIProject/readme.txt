Controls:

movement:
	w: move the character up.
	s: move the character down.
	a: move the character left
	d: move the character right

attacks:
	j:	melee attack.(only valid if the monster is next to you in four directions: UP, DOWN, LEFT, RIGHT)
	k: range attack (sorceries). (only valid if the character is equipped with sorceries weapons. (Wind Staff, Water Staff, Fire Staff, Wood Staff, Magic Fang)

accessories:
	i: get Status of the character, and can equip, throw, or use objects. (Instructions is inside.)
	p: pick up objects in the map when the character is just on the objects. The object is appended to the end of the inventory. 
	n: when the character is on the stairs(ladder), press n to go to the next level of the dungeon.
	1: (Warning: The button will make the game boring.) press 1 to cheat. The character will be invincible.

in start screen:
	s or Return: to start playing the game.

in inventory screen:
	z: resume game
	u: throw the last items in inventory to the map.
	w, x, y: unequip the equipment on character. (ARMOR, WEAPON, SHIELD)
	other button: there are letter start from a that numbered the objects in inventory. press correspond button to use or equip different objects. 

tips:
    1. Because the game's map, location of monster are all generated in random manner. So there will be situation that a lot of monster is surrounding the player. There is only grantee that the monster will not be born in the the start room of each level of maze.
    2. The dark witches, that are born in the map after the second level, will use "meteor" to attack character. That means, it can attack player within a certain distance, and the attack will not miss. They can attack the player even when there are walls between then.
    3. There are 'DEX' attribute of each character, including player. So the player will respond to the next command after few times once a command is make. So if you want to pick up objects on the map but actually you do not, press p to try again.



	
